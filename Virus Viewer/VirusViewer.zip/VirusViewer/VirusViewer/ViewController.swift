//
//  ViewController.swift
//  VirusViewer
//
//  Created by 2020-2 on 2/21/20.
//  Copyright © 2020 Alejandra HV. All rights reserved.
//

// Kit de User Interface
import UIKit

// Herencia de UIViewController
class ViewController: UIViewController {
    
    /* ATRIBUTOS DE CLASE */
    // Inicializar un string vacío
    var pictures = [String]()

    // Sobreescribir el mètodo heredado de UIViewController para cambiar el comportamiento.
    override func viewDidLoad() {
        // super = para referirse al padre y ejecutar el comportamiento del padre.
        // Adicional se desea comportarse de diferente manera
        super.viewDidLoad()
        
        /* ATRIBUTOS */
        // Instancia de clase FileManager.default para acceder al sistema de archivos.
        let fm = FileManager.default
        // Bundle = Representación de código y recursos, es decir, la ruta del main del proyecto.
        // '!' para forzar el desenvolvimiento
        let path = Bundle.main.resourcePath!
        // Acceder a los contenidos del path
        let items = try! fm.contentsOfDirectory(atPath: path)
        
        for item in items{
            if item.hasPrefix("virus"){
                pictures.append(item)
            }
        }
        print(pictures)
    }

    // didReceiveMemoryWarning() advierte cuando puede haber un conflicto con la memoria, para que se escriba el código necesario para solucionarlo y el Sistema Operativo sepa que se atendieron sus advertencias.

}

