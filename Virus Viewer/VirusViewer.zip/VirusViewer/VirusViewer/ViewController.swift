//
//  ViewController.swift
//  VirusViewer
//
//  Created by 2020-2 on 2/21/20.
//  Copyright © 2020 Alejandra HV. All rights reserved.
//

// Kit de User Interface
import UIKit

// Herencia de UITableViewController
class ViewController: UITableViewController {
    
    /* ATRIBUTOS DE CLASE */
    // Inicializar un string vacío
    var pictures = [String]()

    // Sobreescribir el mètodo heredado de UIViewController para cambiar el comportamiento.
    override func viewDidLoad() {
        // super = para referirse al padre y ejecutar el comportamiento del padre.
        // Adicional se desea comportarse de diferente manera
        super.viewDidLoad()
        navigationController?.navigationBar.prefersLargeTitles = true
            title = "Virus viewer"
        
        /* ATRIBUTOS */
        // Instancia de clase FileManager.default para acceder al sistema de archivos.
        let fm = FileManager.default
        // Bundle = Representación de código y recursos, es decir, la ruta del main del proyecto.
        // '!' para forzar el desenvolvimiento
        let path = Bundle.main.resourcePath!
        // Acceder a los contenidos del path
        let items = try! fm.contentsOfDirectory(atPath: path)
        
        for item in items{
            if item.hasPrefix("virus"){
                pictures.append(item)
            }
        }
        print(pictures)
    }
    
    // Regresa el tamaño del arreglo.
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pictures.count
    }
    
    // Sacar una celda de cierto tipo (Desencolar). Permite el reciclaje de las celdas.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        // Con esta línea se obtiene una celda disponible para modificar
        let cell = tableView.dequeueReusableCell(withIdentifier: "Picture", for: indexPath)
        // Contenido de etiqueta de texto en 'Picture' del ViewController en Main.storyboard
        // Propiedad row nos da el entero al que se está refiriendo.
        cell.textLabel?.text = pictures[indexPath.row]
        return cell
    }
    
    // Cada que el usuario de click en un renglón se manda a llamar.
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // 1. Tratar de encontrar y relacionar la vista Detail
        // as? para preguntar si es de ese tipo
        if let vc = storyboard?.instantiateViewController(withIdentifier: "Detail") as? DetailViewController
        {
            // 2. Exito, ya tengo referencia al view controller por medio del vc. Asignar slecteImage al string que está tocando el usuario.
            vc.selectedImage = pictures[indexPath.row]
            // 3. Cambiar la vista.
            navigationController?.pushViewController(vc, animated: true)
        }
    }

    // didReceiveMemoryWarning() advierte cuando puede haber un conflicto con la memoria, para que se escriba el código necesario para solucionarlo y el Sistema Operativo sepa que se atendieron sus advertencias.

}

