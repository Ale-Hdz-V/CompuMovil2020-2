//
//  ViewController.swift
//  Traffic Viewer
//
//  Created by 2020-2 on 13/03/20.
//  Copyright © 2020 Alejandra HV. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // Por ser la primera pantalla, este ViewController está referido específicamente a la pantalla verde de la aplicacìón
    
    // Ligando el textfield de la pantalla verde
    @IBOutlet weak var textfield: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    // Para regresar a la pantalla verde
    @IBAction func unwindToGreen(unwindSegue : UIStoryboardSegue)
    {
    }
    
    // Se va a llamar siempre que haya un segue de mi vista hacia otro lado. Pone a disposiciòn el segue y el sender, puedo ver qué segue se ejecuta y quién es el sender.
    // De la pantalla verde está llegando la referencia a la flecha.
    // Segue automático permite cambiar el título constantemente.
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(textfield.text == "Hola"){
            // El title del navigationItem y el textfield pueden ser nulos, por lo que no hay problema al igualarlos.
            segue.destination.navigationItem.title = textfield.text
        }
    }
    
    @IBAction func buttonSegue(_ sender: Any) {
        print("Boton")
        if(textfield.text == "Hola"){
                // Mandar a llamar el segue.
                performSegue(withIdentifier: "Yellow", sender: nil)
        }
    }
}
