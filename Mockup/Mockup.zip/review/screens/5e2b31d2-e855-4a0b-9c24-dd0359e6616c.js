var content='<div class="ui-page" deviceName="iPhone6" deviceType="mobile" deviceWidth="375" deviceHeight="667">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="667">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1588467792695.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1588467792695-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1588467792695-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-5e2b31d2-e855-4a0b-9c24-dd0359e6616c" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Loading_alert" width="375" height="667">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/5e2b31d2-e855-4a0b-9c24-dd0359e6616c-1588467792695.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/5e2b31d2-e855-4a0b-9c24-dd0359e6616c-1588467792695-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/5e2b31d2-e855-4a0b-9c24-dd0359e6616c-1588467792695-ie8.css" /><![endif]-->\
      <div id="s-Logo" class="pie image firer click ie-background commentable non-processed"   datasizewidth="290px" datasizeheight="206px" dataX="43" dataY="196"   alt="image">\
          <img src="./images/5e822ba6-9b65-4c69-951d-04e8fd884e5d.png" />\
      </div>\
      <div id="s-text_load" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="155px" datasizeheight="28px" dataX="120" dataY="401" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-text_load_0">L O A D I N G . . . </span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;