var content='<div class="ui-page" deviceName="iPhone6" deviceType="mobile" deviceWidth="375" deviceHeight="667">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="667">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1588467792695.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1588467792695-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1588467792695-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-a0a6e906-8d12-4a0d-b0e5-44a90d9aa375" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer click commentable non-processed" alignment="left" name="alert" width="375" height="667">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/a0a6e906-8d12-4a0d-b0e5-44a90d9aa375-1588467792695.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/a0a6e906-8d12-4a0d-b0e5-44a90d9aa375-1588467792695-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/a0a6e906-8d12-4a0d-b0e5-44a90d9aa375-1588467792695-ie8.css" /><![endif]-->\
      <div id="shapewrapper-s-Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="164px" datasizeheight="165px" dataX="109" dataY="61" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_1)">\
                          <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape firer commentable non-processed" cx="82.0" cy="82.5" rx="82.0" ry="82.5">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                          <ellipse cx="82.0" cy="82.5" rx="82.0" ry="82.5">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="shapert-clipping">\
              <div id="shapert-s-Ellipse_1" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_1_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed"   datasizewidth="316px" datasizeheight="160px" dataX="33" dataY="253" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">Se detect&oacute; tos, fiebre y dificultad para respirar en los &uacute;ltimos d&iacute;as, podr&iacute;a tratarse de COVID-19.<br /><br />Acude a tu m&eacute;dico y contacta a las siguientes personas para solicitarles que se realicen un chequeo:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-YourContacts_List" summary="" class="pie datalist firer ie-background commentable non-processed" datamaster="Your Contacts" datasizewidth="200px" datasizeheight="35px" dataX="91" dataY="402" originalwidth="200px" originalheight="35px"  size="6">\
        <div class="backgroundLayer"></div>\
        <table  >\
          <thead>\
            <tr id="s-Header_2" class="headerrow firer ie-background non-processed">\
              <td class="hidden"></td>\
              <td id="s-Row_cell_3" class="pie datacell firer ie-background non-processed"  datasizewidth="200px" datasizeheight="35px" dataX="0" dataY="0" originalwidth="200px" originalheight="35px" >\
                <div class="layout scrollable">\
                  <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable hidden non-processed"   datasizewidth="102px" datasizeheight="21px" dataX="10" dataY="10" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Your Contacts</span></div></div></div></div>\
\
                </div>\
              </td>\
            </tr>\
          </thead>\
          <tbody><tr><td></td></tr></tbody>\
        </table>\
      </div>\
\
      <!-- START DATA VIEW TEMPLATES -->\
      <script type="text/x-jquery-tmpl" id="s-YourContacts_List-template">\
        <![CDATA[\
        <tr id="s-Current_row_2" class="datarow firer ie-background non-processed {{? it.index>6}}hidden{{?}}" align="center">\
          <td class="hidden">\
            <input type="hidden" name="id" value="{{=it.id}}" />\
            <input type="hidden" name="datamaster" value="{{=it.datamaster}}" />\
            <input type="hidden" name="index" value="{{=it.index}}" />\
          </td>\
          <td id="s-Row_cell_4" class="pie datacell firer ie-background non-processed"  datasizewidth="200px" datasizeheight="36px" dataX="0" dataY="0" originalwidth="200px" originalheight="36px" >\
            <div class="layout scrollable">\
              <table class="layout" summary="">\
                <tr>\
                  <td class="layout vertical insertionpoint verticalalign Row_cell_4 YourContacts_List" valign="top" align="center" hSpacing="0" vSpacing="0"><div id="s-Input_2" class="pie text firer ie-background commentable non-processed"  datasizewidth="110px" datasizeheight="20px" dataX="45" dataY="0" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text" name="Your Contacts" value="{{!it.userdata["Your Contacts"]}}" maxlength="100" readonly="readonly" tabindex="-1" placeholder=""/></div></div>  </div></div></td> \
                </tr>\
              </table>\
\
            </div>\
          </td>\
        </tr>\
        ]]>\
      </script>\
      <!-- END DATA VIEW TEMPLATES -->\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;