var content='<div class="ui-page" deviceName="iPhone6" deviceType="mobile" deviceWidth="375" deviceHeight="667">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile devIOS canvas firer commentable non-processed" alignment="left" name="Template 1" width="375" height="667">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1588467792695.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1588467792695-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1588467792695-ie8.css" /><![endif]-->\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-8e063270-47fd-4daf-9a7e-e5e7241accb4" class="screen growth-vertical devMobile devIOS canvas PORTRAIT firer click ie-background commentable non-processed" alignment="left" name="Edit" width="375" height="667">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/8e063270-47fd-4daf-9a7e-e5e7241accb4-1588467792695.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/8e063270-47fd-4daf-9a7e-e5e7241accb4-1588467792695-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/8e063270-47fd-4daf-9a7e-e5e7241accb4-1588467792695-ie8.css" /><![endif]-->\
      <div id="s-statusBar" class="group firer ie-background commentable non-processed" datasizewidth="335px" datasizeheight="22px" dataX="27" dataY="0" >\
        <div id="s-hour" class="pie label singleline firer pageload ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="45px" datasizeheight="19px" dataX="27" dataY="3" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-hour_0">4:02</span></div></div></div></div>\
        <div id="s-signal" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="17px" datasizeheight="12px" dataX="66" dataY="3"   alt="image" systemName="./images/8d1d8f61-040d-49c0-90f0-f8d718a6a163.svg" overlay="#000000">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="18px" height="12px" viewBox="0 0 18 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 48.2 (47327) - http://www.bohemiancoding.com/sketch -->\
                <title>Mobile Signal</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="UI-Bars-/-Status-Bars-/-Black-Base" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-293.000000, -17.000000)">\
                    <path d="M294.666667,24.3333333 L295.666667,24.3333333 C296.218951,24.3333333 296.666667,24.7810486 296.666667,25.3333333 L296.666667,27.3333333 C296.666667,27.8856181 296.218951,28.3333333 295.666667,28.3333333 L294.666667,28.3333333 C294.114382,28.3333333 293.666667,27.8856181 293.666667,27.3333333 L293.666667,25.3333333 C293.666667,24.7810486 294.114382,24.3333333 294.666667,24.3333333 Z M299.333333,22.3333333 L300.333333,22.3333333 C300.885618,22.3333333 301.333333,22.7810486 301.333333,23.3333333 L301.333333,27.3333333 C301.333333,27.8856181 300.885618,28.3333333 300.333333,28.3333333 L299.333333,28.3333333 C298.781049,28.3333333 298.333333,27.8856181 298.333333,27.3333333 L298.333333,23.3333333 C298.333333,22.7810486 298.781049,22.3333333 299.333333,22.3333333 Z M304,20 L305,20 C305.552285,20 306,20.4477153 306,21 L306,27.3333333 C306,27.8856181 305.552285,28.3333333 305,28.3333333 L304,28.3333333 C303.447715,28.3333333 303,27.8856181 303,27.3333333 L303,21 C303,20.4477153 303.447715,20 304,20 Z M308.666667,17.6666667 L309.666667,17.6666667 C310.218951,17.6666667 310.666667,18.1143819 310.666667,18.6666667 L310.666667,27.3333333 C310.666667,27.8856181 310.218951,28.3333333 309.666667,28.3333333 L308.666667,28.3333333 C308.114382,28.3333333 307.666667,27.8856181 307.666667,27.3333333 L307.666667,18.6666667 C307.666667,18.1143819 308.114382,17.6666667 308.666667,17.6666667 Z" id="s-signal-Mobile-Signal" fill="#000000" fill-rule="nonzero"></path>\
                </g>\
            </svg>\
        </div>\
        <div id="s-wifi" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="18px" datasizeheight="18px" dataX="43" dataY="0"   alt="image" systemName="./images/a689a171-1b69-412c-8914-008954706a58.svg" overlay="#000000">\
            <svg preserveAspectRatio=\'none\' id="s-wifi-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><title>cacaca</title><path d="M12,8.06a12.51,12.51,0,0,1,8.27,3.12L21.8,9.46A15,15,0,0,0,12,5.54,15,15,0,0,0,2.2,9.45l1.53,1.72A12.49,12.49,0,0,1,12,8.06"/><path d="M12,13a7.6,7.6,0,0,1,5,1.85l1.63-1.82A10.07,10.07,0,0,0,12,10.5,10.08,10.08,0,0,0,5.4,13L7,14.87A7.61,7.61,0,0,1,12,13"/><path d="M15.34,16.69A5.24,5.24,0,0,0,12,15.4a5.24,5.24,0,0,0-3.34,1.29L12,20.44Z"/></svg>\
        </div>\
        <div id="s-batery" class="pie image firer ie-background commentable pin vpin-beginning hpin-end non-processed-pin non-processed"   datasizewidth="25px" datasizeheight="12px" dataX="13" dataY="5"   alt="image" systemName="./images/597a8ec5-9c2a-49ed-8b0f-a2c104518d54.svg" overlay="#000000">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="25px" height="12px" viewBox="0 0 25 12" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 48.2 (47327) - http://www.bohemiancoding.com/sketch -->\
                <title>Battery</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="Bars/Status-Bar/Dark-Status-Bar" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-336.000000, -17.000000)">\
                    <g id="s-batery-Battery" transform="translate(336.000000, 17.000000)">\
                        <rect id="s-batery-Border" stroke="#FFFFFF" opacity="0.35" x="0.5" y="0.833333333" width="21" height="10.3333333" rx="2.66666675"></rect>\
                        <path d="M23,4 L23,8 C23.8047311,7.66122348 24.328038,6.87313328 24.328038,6 C24.328038,5.12686672 23.8047311,4.33877652 23,4" id="s-batery-Cap" fill="#FFFFFF" fill-rule="nonzero" opacity="0.4"></path>\
                        <rect id="s-batery-Capacity" fill="#FFFFFF" fill-rule="nonzero" x="2" y="2.33333333" width="18" height="7.33333333" rx="1.33333337"></rect>\
                    </g>\
                </g>\
            </svg>\
        </div>\
      </div>\
      <div id="s-Signs" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="55px" datasizeheight="25px" dataX="10" dataY="31" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Signs_0">Signs.</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="379px" datasizeheight="2px" dataX="0" dataY="21" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 379 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="shapewrapper-s-Line_2" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="357px" datasizeheight="2px" dataX="8" dataY="319" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 357 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Contact" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="74px" datasizeheight="25px" dataX="10" dataY="336" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Contact_0">Contact.</span></div></div></div></div>\
      <div id="s-Other" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="25px" dataX="25" dataY="241" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Other_0">Otro:</span></div></div></div></div>\
      <div id="s-Input_1" class="pie text firer change commentable non-processed"  datasizewidth="298px" datasizeheight="31px" dataX="46" dataY="270" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Rectangle_12" class="pie percentage rectangle firer commentable pin vpin-beginning hpin-beginning non-processed-percentage non-processed-pin non-processed"   datasizewidth="100%" datasizeheight="53px" dataX="0" dataY="614" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_12_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Button_edit" class="pie button singleline firer click commentable non-processed"   datasizewidth="86px" datasizeheight="30px" dataX="145" dataY="626" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Button_edit_0">Save</span></div></div></div></div>\
      <div id="s-Image_27" class="pie image firer click ie-background commentable pin vpin-beginning hpin-beginning non-processed-pin non-processed"   datasizewidth="13px" datasizeheight="20px" dataX="12" dataY="627"   alt="image" systemName="./images/3fdc8cb4-a2f0-423e-90c3-e1c8910118ab.svg" overlay="#007AFF">\
          <?xml version="1.0" encoding="UTF-8"?>\
          <svg preserveAspectRatio=\'none\' width="13px" height="21px" viewBox="0 0 13 21" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
              <!-- Generator: Sketch 48.2 (47327) - http://www.bohemiancoding.com/sketch -->\
              <title>Chevron</title>\
              <desc>Created with Sketch.</desc>\
              <defs></defs>\
              <g id="s-Image_27-iPhone-X" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd" transform="translate(-8.000000, -272.000000)">\
                  <g id="s-Image_27-Navigation-Bar---Large-Text" transform="translate(0.000000, 216.000000)" fill="#007AFF">\
                      <g id="s-Image_27-Left-Accessory" transform="translate(0.000000, 45.000000)">\
                          <path d="M18.0371349,31.5826673 L8.79215185,22.4458042 C8.40261605,22.0611888 8.40261605,21.4398102 8.79215185,21.0541958 L18.0371349,11.9173327 C18.5994648,11.3608891 19.5143745,11.3608891 20.0777032,11.9173327 C20.6400331,12.4737762 20.6400331,13.3768731 20.0777032,13.9333167 L12.1691276,21.7504995 L20.0777032,29.5656843 C20.6400331,30.1231269 20.6400331,31.0262238 20.0777032,31.5826673 C19.5143745,32.1391109 18.5994648,32.1391109 18.0371349,31.5826673" id="s-Image_27-Chevron"></path>\
                      </g>\
                  </g>\
              </g>\
          </svg>\
      </div>\
      <div id="s-Image_3" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="238" dataY="55"   alt="image" systemName="./images/66729c4b-cd98-4e6c-b1e8-e1fde104bf5d.svg" overlay="#999999">\
          <svg preserveAspectRatio=\'none\' id="s-Image_3-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_3 .cls-1{fill:#666;}</style></defs><title>checkbox</title><path class="cls-1" d="M4,55a1,1,0,0,0,1,1H49a1,1,0,0,0,1-1V28a1,1,0,0,0-2,0V54H6V12H48v5a1,1,0,1,0,2,0V11a1,1,0,0,0-1-1H5a1,1,0,0,0-1,1V55Z"/><path class="cls-1" d="M59.71,12.29a1,1,0,0,0-1.41,0L27,43.59,17.71,34.3a1,1,0,0,0-1.41,1.41l10,10A1,1,0,0,0,27,46a1,1,0,0,0,.71-0.29l32-32A1,1,0,0,0,59.71,12.29Z"/></svg>\
      </div>\
      <div id="s-Text_2" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="199px" datasizeheight="25px" dataX="23" dataY="61" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_2_0">Dificultad para respirar</span></div></div></div></div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="139px" datasizeheight="25px" dataX="23" dataY="92" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Dolor de cabeza</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="133px" datasizeheight="25px" dataX="22" dataY="121" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">Dolor muscular</span></div></div></div></div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="97px" datasizeheight="25px" dataX="22" dataY="150" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">Escalofr&iacute;os</span></div></div></div></div>\
      <div id="s-Text_6" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="54px" datasizeheight="25px" dataX="22" dataY="180" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Fiebre</span></div></div></div></div>\
      <div id="s-Text_7" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="31px" datasizeheight="25px" dataX="22" dataY="210" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_7_0">Tos</span></div></div></div></div>\
      <div id="s-Image_4" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="238" dataY="87"   alt="image" systemName="./images/66729c4b-cd98-4e6c-b1e8-e1fde104bf5d.svg" overlay="#999999">\
          <svg preserveAspectRatio=\'none\' id="s-Image_4-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_4 .cls-1{fill:#666;}</style></defs><title>checkbox</title><path class="cls-1" d="M4,55a1,1,0,0,0,1,1H49a1,1,0,0,0,1-1V28a1,1,0,0,0-2,0V54H6V12H48v5a1,1,0,1,0,2,0V11a1,1,0,0,0-1-1H5a1,1,0,0,0-1,1V55Z"/><path class="cls-1" d="M59.71,12.29a1,1,0,0,0-1.41,0L27,43.59,17.71,34.3a1,1,0,0,0-1.41,1.41l10,10A1,1,0,0,0,27,46a1,1,0,0,0,.71-0.29l32-32A1,1,0,0,0,59.71,12.29Z"/></svg>\
      </div>\
      <div id="s-Image_5" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="238" dataY="119"   alt="image" systemName="./images/66729c4b-cd98-4e6c-b1e8-e1fde104bf5d.svg" overlay="#999999">\
          <svg preserveAspectRatio=\'none\' id="s-Image_5-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_5 .cls-1{fill:#666;}</style></defs><title>checkbox</title><path class="cls-1" d="M4,55a1,1,0,0,0,1,1H49a1,1,0,0,0,1-1V28a1,1,0,0,0-2,0V54H6V12H48v5a1,1,0,1,0,2,0V11a1,1,0,0,0-1-1H5a1,1,0,0,0-1,1V55Z"/><path class="cls-1" d="M59.71,12.29a1,1,0,0,0-1.41,0L27,43.59,17.71,34.3a1,1,0,0,0-1.41,1.41l10,10A1,1,0,0,0,27,46a1,1,0,0,0,.71-0.29l32-32A1,1,0,0,0,59.71,12.29Z"/></svg>\
      </div>\
      <div id="s-Image_6" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="238" dataY="149"   alt="image" systemName="./images/66729c4b-cd98-4e6c-b1e8-e1fde104bf5d.svg" overlay="#999999">\
          <svg preserveAspectRatio=\'none\' id="s-Image_6-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_6 .cls-1{fill:#666;}</style></defs><title>checkbox</title><path class="cls-1" d="M4,55a1,1,0,0,0,1,1H49a1,1,0,0,0,1-1V28a1,1,0,0,0-2,0V54H6V12H48v5a1,1,0,1,0,2,0V11a1,1,0,0,0-1-1H5a1,1,0,0,0-1,1V55Z"/><path class="cls-1" d="M59.71,12.29a1,1,0,0,0-1.41,0L27,43.59,17.71,34.3a1,1,0,0,0-1.41,1.41l10,10A1,1,0,0,0,27,46a1,1,0,0,0,.71-0.29l32-32A1,1,0,0,0,59.71,12.29Z"/></svg>\
      </div>\
      <div id="s-Image_7" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="238" dataY="180"   alt="image" systemName="./images/66729c4b-cd98-4e6c-b1e8-e1fde104bf5d.svg" overlay="#999999">\
          <svg preserveAspectRatio=\'none\' id="s-Image_7-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_7 .cls-1{fill:#666;}</style></defs><title>checkbox</title><path class="cls-1" d="M4,55a1,1,0,0,0,1,1H49a1,1,0,0,0,1-1V28a1,1,0,0,0-2,0V54H6V12H48v5a1,1,0,1,0,2,0V11a1,1,0,0,0-1-1H5a1,1,0,0,0-1,1V55Z"/><path class="cls-1" d="M59.71,12.29a1,1,0,0,0-1.41,0L27,43.59,17.71,34.3a1,1,0,0,0-1.41,1.41l10,10A1,1,0,0,0,27,46a1,1,0,0,0,.71-0.29l32-32A1,1,0,0,0,59.71,12.29Z"/></svg>\
      </div>\
      <div id="s-Image_8" class="pie image firer click ie-background commentable non-processed"   datasizewidth="28px" datasizeheight="28px" dataX="238" dataY="209"   alt="image" systemName="./images/66729c4b-cd98-4e6c-b1e8-e1fde104bf5d.svg" overlay="#999999">\
          <svg preserveAspectRatio=\'none\' id="s-Image_8-Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64"><defs><style>#s-Image_8 .cls-1{fill:#666;}</style></defs><title>checkbox</title><path class="cls-1" d="M4,55a1,1,0,0,0,1,1H49a1,1,0,0,0,1-1V28a1,1,0,0,0-2,0V54H6V12H48v5a1,1,0,1,0,2,0V11a1,1,0,0,0-1-1H5a1,1,0,0,0-1,1V55Z"/><path class="cls-1" d="M59.71,12.29a1,1,0,0,0-1.41,0L27,43.59,17.71,34.3a1,1,0,0,0-1.41,1.41l10,10A1,1,0,0,0,27,46a1,1,0,0,0,.71-0.29l32-32A1,1,0,0,0,59.71,12.29Z"/></svg>\
      </div>\
      <div id="s-Input_2" class="pie text firer change click commentable non-processed"  datasizewidth="298px" datasizeheight="31px" dataX="46" dataY="370" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_3" class="pie text firer change commentable non-processed"  datasizewidth="298px" datasizeheight="31px" dataX="46" dataY="410" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_4" class="pie text firer change commentable non-processed"  datasizewidth="298px" datasizeheight="31px" dataX="46" dataY="449" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_5" class="pie text firer change commentable non-processed"  datasizewidth="298px" datasizeheight="31px" dataX="46" dataY="489" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_6" class="pie text firer change commentable non-processed"  datasizewidth="298px" datasizeheight="31px" dataX="46" dataY="527" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Input_7" class="pie text firer change commentable non-processed"  datasizewidth="298px" datasizeheight="31px" dataX="46" dataY="567" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-Text_1" class="pie label singleline autofit firer ie-background commentable hidden non-processed"   datasizewidth="10px" datasizeheight="18px" dataX="301" dataY="60" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">0</span></div></div></div></div>\
      <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable hidden non-processed"   datasizewidth="10px" datasizeheight="18px" dataX="301" dataY="92" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">0</span></div></div></div></div>\
      <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable hidden non-processed"   datasizewidth="10px" datasizeheight="18px" dataX="301" dataY="124" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">0</span></div></div></div></div>\
      <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable hidden non-processed"   datasizewidth="10px" datasizeheight="18px" dataX="301" dataY="154" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">0</span></div></div></div></div>\
      <div id="s-Text_11" class="pie label singleline autofit firer ie-background commentable hidden non-processed"   datasizewidth="10px" datasizeheight="18px" dataX="301" dataY="184" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">0</span></div></div></div></div>\
      <div id="s-Text_12" class="pie label singleline autofit firer ie-background commentable hidden non-processed"   datasizewidth="10px" datasizeheight="18px" dataX="301" dataY="214" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_12_0">0</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;