(function(window, undefined) {

  var jimLinks = {
    "5e2b31d2-e855-4a0b-9c24-dd0359e6616c" : {
      "Logo" : [
        "8d9a2f16-4790-456d-bfcf-7837c2d8a49b"
      ]
    },
    "8d9a2f16-4790-456d-bfcf-7837c2d8a49b" : {
      "Button_1" : [
        "6dee8bc9-e606-4e1e-a04f-6b3aae6af073"
      ]
    },
    "e52ef747-6255-4a2e-a534-7380a64f3583" : {
      "Image_27" : [
        "a0a6e906-8d12-4a0d-b0e5-44a90d9aa375",
        "314e974c-34d4-4307-bb33-d7a0f406eea6"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Logo" : [
        "6dee8bc9-e606-4e1e-a04f-6b3aae6af073"
      ]
    },
    "27cbc624-4706-4bf8-9e8c-397c92094ea7" : {
      "Logo" : [
        "5e2b31d2-e855-4a0b-9c24-dd0359e6616c"
      ]
    },
    "7285db97-bfbc-4b76-9591-3c4f553056fb" : {
      "Button_Reg" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_Cancel" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Button_login" : [
        "6dee8bc9-e606-4e1e-a04f-6b3aae6af073"
      ]
    },
    "a0a6e906-8d12-4a0d-b0e5-44a90d9aa375" : {
    },
    "314e974c-34d4-4307-bb33-d7a0f406eea6" : {
      "Image_27" : [
        "a5f3cd5a-6b64-4e39-9068-8cf686146ce4"
      ],
      "Button_edit" : [
        "8e063270-47fd-4daf-9a7e-e5e7241accb4"
      ],
      "Text_1" : [
        "e52ef747-6255-4a2e-a534-7380a64f3583"
      ]
    },
    "6dee8bc9-e606-4e1e-a04f-6b3aae6af073" : {
      "Button_login" : [
        "314e974c-34d4-4307-bb33-d7a0f406eea6"
      ],
      "Button_signup" : [
        "7285db97-bfbc-4b76-9591-3c4f553056fb"
      ]
    },
    "8e063270-47fd-4daf-9a7e-e5e7241accb4" : {
      "Button_edit" : [
        "314e974c-34d4-4307-bb33-d7a0f406eea6",
        "314e974c-34d4-4307-bb33-d7a0f406eea6",
        "314e974c-34d4-4307-bb33-d7a0f406eea6",
        "314e974c-34d4-4307-bb33-d7a0f406eea6",
        "314e974c-34d4-4307-bb33-d7a0f406eea6",
        "314e974c-34d4-4307-bb33-d7a0f406eea6",
        "314e974c-34d4-4307-bb33-d7a0f406eea6"
      ],
      "Image_27" : [
        "314e974c-34d4-4307-bb33-d7a0f406eea6"
      ]
    },
    "a5f3cd5a-6b64-4e39-9068-8cf686146ce4" : {
      "Logo" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);