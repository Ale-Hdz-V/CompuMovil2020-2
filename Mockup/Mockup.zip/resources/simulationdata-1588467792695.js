function initData() {
  jimData.variables["Contacts"] = "";
  jimData.datamasters["Your Contacts"] = [
  ];

  jimData.datamasters["Your Signs"] = [
  ];

  jimData.datamasters["Users"] = [
    {
      "id": 1,
      "datamaster": "Users",
      "userdata": {
        "Email": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 2,
      "datamaster": "Users",
      "userdata": {
        "Email": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 3,
      "datamaster": "Users",
      "userdata": {
        "Email": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 4,
      "datamaster": "Users",
      "userdata": {
        "Email": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 5,
      "datamaster": "Users",
      "userdata": {
        "Email": "sample text",
        "Password": "sample text"
      }
    },
    {
      "id": 6,
      "datamaster": "Users",
      "userdata": {
        "Email": "sample text",
        "Password": "sample text"
      }
    }
  ];

  jimData.isInitialized = true;
}