jQuery("#simulation")
  .on("click", ".s-8d9a2f16-4790-456d-bfcf-7837c2d8a49b .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Signs"
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6dee8bc9-e606-4e1e-a04f-6b3aae6af073",
                    "transition": {
                      "type": "flipvertical",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });