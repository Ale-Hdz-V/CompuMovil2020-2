jQuery("#simulation")
  .on("click", ".s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Button_login")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimAnd",
                    "parameter": [ {
                      "action": "jimRegExp",
                      "parameter": [ {
                        "datatype": "property",
                        "target": "#s-E-mail",
                        "property": "jimGetValue"
                      },"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?" ]
                    },{
                      "action": "jimEquals",
                      "parameter": [ {
                        "action": "jimSelectData",
                        "parameter": {
                          "action": "jimFilterData",
                          "parameter": {
                            "datatype": "datamaster",
                            "datamaster": "Users",
                            "value": {
                              "action": "jimEquals",
                              "parameter": [ {
                                "field": "Password"
                              },{
                                "datatype": "property",
                                "target": "#s-Psswd",
                                "property": "jimGetValue"
                              } ]
                            }
                          },
                          "value": {
                            "field": "Password"
                          }
                        }
                      },{
                        "datatype": "property",
                        "target": "#s-Psswd",
                        "property": "jimGetValue"
                      } ]
                    } ]
                  },{
                    "action": "jimNotEquals",
                    "parameter": [ {
                      "datatype": "property",
                      "target": "#s-Psswd",
                      "property": "jimGetValue"
                    },"" ]
                  } ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "action": "jimSelectData",
                    "parameter": {
                      "action": "jimFilterData",
                      "parameter": {
                        "datatype": "datamaster",
                        "datamaster": "Users",
                        "value": {
                          "action": "jimEquals",
                          "parameter": [ {
                            "field": "Email"
                          },{
                            "datatype": "property",
                            "target": "#s-E-mail",
                            "property": "jimGetValue"
                          } ]
                        }
                      },
                      "value": {
                        "field": "Email"
                      }
                    }
                  },{
                    "datatype": "property",
                    "target": "#s-E-mail",
                    "property": "jimGetValue"
                  } ]
                } ]
              },
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/314e974c-34d4-4307-bb33-d7a0f406eea6",
                    "transition": {
                      "type": "fade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 #s-Psswd > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FF9191"
                      }
                    }
                  },{
                    "#s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 #s-Psswd": {
                      "attributes-ie": {
                        "-pie-background": "#FF9191",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 #s-Psswd INPUT": {
                      "attributes-ie8lte": {
                        "font-family": "Arial"
                      }
                    }
                  },{
                    "#s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 #s-E-mail > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FF9191"
                      }
                    }
                  },{
                    "#s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 #s-E-mail": {
                      "attributes-ie": {
                        "-pie-background": "#FF9191",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Dialog" ],
                    "effect": {
                      "type": "bounce",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_signup")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/7285db97-bfbc-4b76-9591-3c4f553056fb",
                    "transition": {
                      "type": "fade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Label_27")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dialog" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("pageload", ".s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 .pageload", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-hour")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-hour" ],
                    "value": {
                      "action": "jimSubstring",
                      "parameter": [ {
                        "action": "jimSystemTime"
                      },"0","5" ]
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("change", ".s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 .change", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-E-mail")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimRegExp",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-E-mail",
                  "property": "jimGetValue"
                },"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 #s-E-mail > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 #s-E-mail": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Psswd")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 #s-Psswd > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 #s-Psswd": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-6dee8bc9-e606-4e1e-a04f-6b3aae6af073 #s-Psswd INPUT": {
                      "attributes-ie8lte": {
                        "font-family": "Arial"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });