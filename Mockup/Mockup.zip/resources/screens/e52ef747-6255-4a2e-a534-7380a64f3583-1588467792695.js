jQuery("#simulation")
  .on("click", ".s-e52ef747-6255-4a2e-a534-7380a64f3583 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Image_27")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimEquals",
                    "parameter": [ {
                      "action": "jimSelectData",
                      "parameter": {
                        "action": "jimFilterData",
                        "parameter": {
                          "datatype": "datamaster",
                          "datamaster": "Your Signs",
                          "value": {
                            "action": "jimEquals",
                            "parameter": [ {
                              "field": "Your Signs"
                            },"Dificultad para respirar" ]
                          }
                        },
                        "value": {
                          "field": "Your Signs"
                        }
                      }
                    },"Dificultad para respirar" ]
                  },{
                    "action": "jimEquals",
                    "parameter": [ {
                      "action": "jimSelectData",
                      "parameter": {
                        "action": "jimFilterData",
                        "parameter": {
                          "datatype": "datamaster",
                          "datamaster": "Your Signs",
                          "value": {
                            "action": "jimEquals",
                            "parameter": [ {
                              "field": "Your Signs"
                            },"Fiebre" ]
                          }
                        },
                        "value": {
                          "field": "Your Signs"
                        }
                      }
                    },"Fiebre" ]
                  } ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "action": "jimSelectData",
                    "parameter": {
                      "action": "jimFilterData",
                      "parameter": {
                        "datatype": "datamaster",
                        "datamaster": "Your Signs",
                        "value": {
                          "action": "jimEquals",
                          "parameter": [ {
                            "field": "Your Signs"
                          },"Tos" ]
                        }
                      },
                      "value": {
                        "field": "Your Signs"
                      }
                    }
                  },"Tos" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/a0a6e906-8d12-4a0d-b0e5-44a90d9aa375",
                    "transition": {
                      "type": "fade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/314e974c-34d4-4307-bb33-d7a0f406eea6",
                    "transition": {
                      "type": "fade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("pageload", ".s-e52ef747-6255-4a2e-a534-7380a64f3583 .pageload", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-hour")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-hour" ],
                    "value": {
                      "action": "jimSubstring",
                      "parameter": [ {
                        "action": "jimSystemTime"
                      },"0","5" ]
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });