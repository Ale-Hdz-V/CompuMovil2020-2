jQuery("#simulation")
  .on("click", ".s-7285db97-bfbc-4b76-9591-3c4f553056fb .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-7285db97-bfbc-4b76-9591-3c4f553056fb")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimScrollTo",
                  "parameter": {
                    "target": [ "#s-statusBar" ],
                    "axis": "scrolly",
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Psswd_conf")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Button_login": {
                      "attributes": {
                        "padding-bottom": "250px"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimScrollTo",
                  "parameter": {
                    "target": [ "#s-Psswd_conf" ],
                    "axis": "scrolly",
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_Reg")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "action": "jimSelectData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Users",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Email"
                        },{
                          "datatype": "property",
                          "target": "#s-E-mail",
                          "property": "jimGetValue"
                        } ]
                      }
                    },
                    "value": {
                      "field": "Email"
                    }
                  }
                },{
                  "datatype": "property",
                  "target": "#s-E-mail",
                  "property": "jimGetValue"
                } ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-E-mail > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FF9191"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-E-mail": {
                      "attributes-ie": {
                        "-pie-background": "#FF9191",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimShow",
                  "parameter": {
                    "target": [ "#s-Dialog" ],
                    "effect": {
                      "type": "bounce",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimRegExp",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-E-mail",
                    "property": "jimGetValue"
                  },"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?" ]
                },{
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimNotEquals",
                    "parameter": [ {
                      "datatype": "property",
                      "target": "#s-Psswd",
                      "property": "jimGetValue"
                    },"" ]
                  },{
                    "action": "jimEquals",
                    "parameter": [ {
                      "datatype": "property",
                      "target": "#s-Psswd",
                      "property": "jimGetValue"
                    },{
                      "datatype": "property",
                      "target": "#s-Psswd_conf",
                      "property": "jimGetValue"
                    } ]
                  } ]
                } ]
              },
              "actions": [
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Users",
                    "fields": {
                      "Email": {
                        "datatype": "property",
                        "target": "#s-E-mail",
                        "property": "jimGetValue"
                      },
                      "Password": {
                        "datatype": "property",
                        "target": "#s-Psswd_conf",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724",
                    "transition": {
                      "type": "fade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-E-mail > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FF9191"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-E-mail": {
                      "attributes-ie": {
                        "-pie-background": "#FF9191",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FF9191"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd": {
                      "attributes-ie": {
                        "-pie-background": "#FF9191",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd INPUT": {
                      "attributes-ie8lte": {
                        "font-family": "Arial"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd_conf > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FF9191"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd_conf": {
                      "attributes-ie": {
                        "-pie-background": "#FF9191",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd_conf INPUT": {
                      "attributes-ie8lte": {
                        "font-family": "Arial"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_Cancel")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/d12245cc-1680-458d-89dd-4f0d7fb22724",
                    "transition": {
                      "type": "fade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_login")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/6dee8bc9-e606-4e1e-a04f-6b3aae6af073",
                    "transition": {
                      "type": "fade",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Label_27")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimHide",
                  "parameter": {
                    "target": [ "#s-Dialog" ]
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("pageload", ".s-7285db97-bfbc-4b76-9591-3c4f553056fb .pageload", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-hour")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-hour" ],
                    "value": {
                      "action": "jimSubstring",
                      "parameter": [ {
                        "action": "jimSystemTime"
                      },"0","5" ]
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("change", ".s-7285db97-bfbc-4b76-9591-3c4f553056fb .change", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-E-mail")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimRegExp",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-E-mail",
                  "property": "jimGetValue"
                },"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?" ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-E-mail > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-E-mail": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-E-mail > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FF9191"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-E-mail": {
                      "attributes-ie": {
                        "-pie-background": "#FF9191",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Psswd")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd INPUT": {
                      "attributes-ie8lte": {
                        "font-family": "Arial"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Psswd_conf")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Psswd",
                  "property": "jimGetValue"
                },{
                  "datatype": "property",
                  "target": "#s-Psswd_conf",
                  "property": "jimGetValue"
                } ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd_conf > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd_conf": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd_conf INPUT": {
                      "attributes-ie8lte": {
                        "font-family": "Arial"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd_conf > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#FF9191"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd_conf": {
                      "attributes-ie": {
                        "-pie-background": "#FF9191",
                        "-pie-poll": "false"
                      }
                    }
                  },{
                    "#s-7285db97-bfbc-4b76-9591-3c4f553056fb #s-Psswd_conf INPUT": {
                      "attributes-ie8lte": {
                        "font-family": "Arial"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });