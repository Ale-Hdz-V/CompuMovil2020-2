jQuery("#simulation")
  .on("click", ".s-8e063270-47fd-4daf-9a7e-e5e7241accb4 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-8e063270-47fd-4daf-9a7e-e5e7241accb4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimScrollTo",
                  "parameter": {
                    "target": [ "#s-statusBar" ],
                    "axis": "scrolly",
                    "effect": {
                      "type": "none",
                      "easing": "linear",
                      "duration": 500
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Button_edit")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimNotEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Input_1",
                  "property": "jimGetValue"
                },"" ]
              },
              "actions": [
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Signs",
                    "fields": {
                      "Your Signs": {
                        "datatype": "property",
                        "target": "#s-Input_1",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimAnd",
                    "parameter": [ {
                      "action": "jimAnd",
                      "parameter": [ {
                        "action": "jimNotEquals",
                        "parameter": [ {
                          "datatype": "property",
                          "target": "#s-Input_2",
                          "property": "jimGetValue"
                        },"" ]
                      },{
                        "action": "jimNotEquals",
                        "parameter": [ {
                          "datatype": "property",
                          "target": "#s-Input_3",
                          "property": "jimGetValue"
                        },"" ]
                      } ]
                    },{
                      "action": "jimNotEquals",
                      "parameter": [ {
                        "datatype": "property",
                        "target": "#s-Input_4",
                        "property": "jimGetValue"
                      },"" ]
                    } ]
                  },{
                    "action": "jimNotEquals",
                    "parameter": [ {
                      "datatype": "property",
                      "target": "#s-Input_5",
                      "property": "jimGetValue"
                    },"" ]
                  } ]
                },{
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimNotEquals",
                    "parameter": [ {
                      "datatype": "property",
                      "target": "#s-Input_6",
                      "property": "jimGetValue"
                    },"" ]
                  },{
                    "action": "jimNotEquals",
                    "parameter": [ {
                      "datatype": "property",
                      "target": "#s-Input_7",
                      "property": "jimGetValue"
                    },"" ]
                  } ]
                } ]
              },
              "actions": [
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_2",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_3",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_4",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_5",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_6",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_7",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/314e974c-34d4-4307-bb33-d7a0f406eea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimAnd",
                    "parameter": [ {
                      "action": "jimAnd",
                      "parameter": [ {
                        "action": "jimNotEquals",
                        "parameter": [ {
                          "datatype": "property",
                          "target": "#s-Input_2",
                          "property": "jimGetValue"
                        },"" ]
                      },{
                        "action": "jimNotEquals",
                        "parameter": [ {
                          "datatype": "property",
                          "target": "#s-Input_3",
                          "property": "jimGetValue"
                        },"" ]
                      } ]
                    },{
                      "action": "jimNotEquals",
                      "parameter": [ {
                        "datatype": "property",
                        "target": "#s-Input_4",
                        "property": "jimGetValue"
                      },"" ]
                    } ]
                  },{
                    "action": "jimNotEquals",
                    "parameter": [ {
                      "datatype": "property",
                      "target": "#s-Input_5",
                      "property": "jimGetValue"
                    },"" ]
                  } ]
                },{
                  "action": "jimNotEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_6",
                    "property": "jimGetValue"
                  },"" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_2",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_3",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_4",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_5",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_6",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/314e974c-34d4-4307-bb33-d7a0f406eea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimAnd",
                    "parameter": [ {
                      "action": "jimNotEquals",
                      "parameter": [ {
                        "datatype": "property",
                        "target": "#s-Input_2",
                        "property": "jimGetValue"
                      },"" ]
                    },{
                      "action": "jimNotEquals",
                      "parameter": [ {
                        "datatype": "property",
                        "target": "#s-Input_3",
                        "property": "jimGetValue"
                      },"" ]
                    } ]
                  },{
                    "action": "jimNotEquals",
                    "parameter": [ {
                      "datatype": "property",
                      "target": "#s-Input_4",
                      "property": "jimGetValue"
                    },"" ]
                  } ]
                },{
                  "action": "jimNotEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_5",
                    "property": "jimGetValue"
                  },"" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_2",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_3",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_4",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_5",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/314e974c-34d4-4307-bb33-d7a0f406eea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimAnd",
                  "parameter": [ {
                    "action": "jimNotEquals",
                    "parameter": [ {
                      "datatype": "property",
                      "target": "#s-Input_2",
                      "property": "jimGetValue"
                    },"" ]
                  },{
                    "action": "jimNotEquals",
                    "parameter": [ {
                      "datatype": "property",
                      "target": "#s-Input_3",
                      "property": "jimGetValue"
                    },"" ]
                  } ]
                },{
                  "action": "jimNotEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_4",
                    "property": "jimGetValue"
                  },"" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_2",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_3",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_4",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/314e974c-34d4-4307-bb33-d7a0f406eea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimNotEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_2",
                    "property": "jimGetValue"
                  },"" ]
                },{
                  "action": "jimNotEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Input_3",
                    "property": "jimGetValue"
                  },"" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_2",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_3",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/314e974c-34d4-4307-bb33-d7a0f406eea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "condition": {
                "action": "jimNotEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Input_2",
                  "property": "jimGetValue"
                },"" ]
              },
              "actions": [
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Contacts",
                    "fields": {
                      "Your Contacts": {
                        "datatype": "property",
                        "target": "#s-Input_2",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/314e974c-34d4-4307-bb33-d7a0f406eea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/314e974c-34d4-4307-bb33-d7a0f406eea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_27")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Text_1",
                  "property": "jimGetValue"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_2",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Text_8",
                  "property": "jimGetValue"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_2",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Text_9",
                  "property": "jimGetValue"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_4",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Text_10",
                  "property": "jimGetValue"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_5",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Text_11",
                  "property": "jimGetValue"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_6",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        },
        {
          "blocks": [
            {
              "condition": {
                "action": "jimEquals",
                "parameter": [ {
                  "datatype": "property",
                  "target": "#s-Text_12",
                  "property": "jimGetValue"
                },"1" ]
              },
              "actions": [
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_7",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        },
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Input_1",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/314e974c-34d4-4307-bb33-d7a0f406eea6"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "parallel",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_3")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Text_1",
                    "property": "jimGetValue"
                  },"0" ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "action": "jimCountData",
                    "parameter": {
                      "action": "jimFilterData",
                      "parameter": {
                        "datatype": "datamaster",
                        "datamaster": "Your Signs",
                        "value": {
                          "action": "jimEquals",
                          "parameter": [ {
                            "field": "Your Signs"
                          },{
                            "datatype": "property",
                            "target": "#s-Text_2",
                            "property": "jimGetValue"
                          } ]
                        }
                      }
                    }
                  },"0" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_3 > svg": {
                      "attributes": {
                        "overlay": "#00FF00"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Signs",
                    "fields": {
                      "Your Signs": {
                        "datatype": "property",
                        "target": "#s-Text_2",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_1" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_3 > svg": {
                      "attributes": {
                        "overlay": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_2",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_1" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_4")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Text_8",
                    "property": "jimGetValue"
                  },"0" ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "action": "jimCountData",
                    "parameter": {
                      "action": "jimFilterData",
                      "parameter": {
                        "datatype": "datamaster",
                        "datamaster": "Your Signs",
                        "value": {
                          "action": "jimEquals",
                          "parameter": [ {
                            "field": "Your Signs"
                          },{
                            "datatype": "property",
                            "target": "#s-Text_3",
                            "property": "jimGetValue"
                          } ]
                        }
                      }
                    }
                  },"0" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_4 > svg": {
                      "attributes": {
                        "overlay": "#00FF00"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Signs",
                    "fields": {
                      "Your Signs": {
                        "datatype": "property",
                        "target": "#s-Text_3",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_8" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_4 > svg": {
                      "attributes": {
                        "overlay": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_3",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_8" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_5")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Text_9",
                    "property": "jimGetValue"
                  },"0" ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "action": "jimCountData",
                    "parameter": {
                      "action": "jimFilterData",
                      "parameter": {
                        "datatype": "datamaster",
                        "datamaster": "Your Signs",
                        "value": {
                          "action": "jimEquals",
                          "parameter": [ {
                            "field": "Your Signs"
                          },{
                            "datatype": "property",
                            "target": "#s-Text_4",
                            "property": "jimGetValue"
                          } ]
                        }
                      }
                    }
                  },"0" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_5 > svg": {
                      "attributes": {
                        "overlay": "#00FF00"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Signs",
                    "fields": {
                      "Your Signs": {
                        "datatype": "property",
                        "target": "#s-Text_4",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_9" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_5 > svg": {
                      "attributes": {
                        "overlay": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_4",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_9" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_6")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Text_10",
                    "property": "jimGetValue"
                  },"0" ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "action": "jimCountData",
                    "parameter": {
                      "action": "jimFilterData",
                      "parameter": {
                        "datatype": "datamaster",
                        "datamaster": "Your Signs",
                        "value": {
                          "action": "jimEquals",
                          "parameter": [ {
                            "field": "Your Signs"
                          },{
                            "datatype": "property",
                            "target": "#s-Text_5",
                            "property": "jimGetValue"
                          } ]
                        }
                      }
                    }
                  },"0" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_6 > svg": {
                      "attributes": {
                        "overlay": "#00FF00"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Signs",
                    "fields": {
                      "Your Signs": {
                        "datatype": "property",
                        "target": "#s-Text_5",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_10" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_6 > svg": {
                      "attributes": {
                        "overlay": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_5",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_10" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_7")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Text_11",
                    "property": "jimGetValue"
                  },"0" ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "action": "jimCountData",
                    "parameter": {
                      "action": "jimFilterData",
                      "parameter": {
                        "datatype": "datamaster",
                        "datamaster": "Your Signs",
                        "value": {
                          "action": "jimEquals",
                          "parameter": [ {
                            "field": "Your Signs"
                          },{
                            "datatype": "property",
                            "target": "#s-Text_6",
                            "property": "jimGetValue"
                          } ]
                        }
                      }
                    }
                  },"0" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_7 > svg": {
                      "attributes": {
                        "overlay": "#00FF00"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Signs",
                    "fields": {
                      "Your Signs": {
                        "datatype": "property",
                        "target": "#s-Text_6",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_11" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_7 > svg": {
                      "attributes": {
                        "overlay": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_6",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_11" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Image_8")) {
      cases = [
        {
          "blocks": [
            {
              "condition": {
                "action": "jimAnd",
                "parameter": [ {
                  "action": "jimEquals",
                  "parameter": [ {
                    "datatype": "property",
                    "target": "#s-Text_12",
                    "property": "jimGetValue"
                  },"0" ]
                },{
                  "action": "jimEquals",
                  "parameter": [ {
                    "action": "jimCountData",
                    "parameter": {
                      "action": "jimFilterData",
                      "parameter": {
                        "datatype": "datamaster",
                        "datamaster": "Your Signs",
                        "value": {
                          "action": "jimEquals",
                          "parameter": [ {
                            "field": "Your Signs"
                          },{
                            "datatype": "property",
                            "target": "#s-Text_7",
                            "property": "jimGetValue"
                          } ]
                        }
                      }
                    }
                  },"0" ]
                } ]
              },
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_8 > svg": {
                      "attributes": {
                        "overlay": "#00FF00"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimCreateData",
                  "parameter": {
                    "datatype": "datamaster",
                    "datamaster": "Your Signs",
                    "fields": {
                      "Your Signs": {
                        "datatype": "property",
                        "target": "#s-Text_7",
                        "property": "jimGetValue"
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_12" ],
                    "value": "1"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            },
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Image_8 > svg": {
                      "attributes": {
                        "overlay": "#999999"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimDeleteData",
                  "parameter": {
                    "action": "jimFilterData",
                    "parameter": {
                      "datatype": "datamaster",
                      "datamaster": "Your Signs",
                      "value": {
                        "action": "jimEquals",
                        "parameter": [ {
                          "field": "Your Signs"
                        },{
                          "datatype": "property",
                          "target": "#s-Text_7",
                          "property": "jimGetValue"
                        } ]
                      }
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-Text_12" ],
                    "value": "0"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_7": {
                      "attributes": {
                        "padding-bottom": "300px"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_4": {
                      "attributes": {
                        "padding-bottom": "300px"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_3": {
                      "attributes": {
                        "padding-bottom": "300px"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_5": {
                      "attributes": {
                        "padding-bottom": "300px"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_2": {
                      "attributes": {
                        "padding-bottom": "300px"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_6": {
                      "attributes": {
                        "padding-bottom": "300px"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                },
                {
                  "action": "jimScrollTo",
                  "parameter": {
                    "target": [ "#s-Input_2" ],
                    "axis": "scrollxy"
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("pageload", ".s-8e063270-47fd-4daf-9a7e-e5e7241accb4 .pageload", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-hour")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimSetValue",
                  "parameter": {
                    "target": [ "#s-hour" ],
                    "value": {
                      "action": "jimSubstring",
                      "parameter": [ {
                        "action": "jimSystemTime"
                      },"0","5" ]
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  })
  .on("change", ".s-8e063270-47fd-4daf-9a7e-e5e7241accb4 .change", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-Input_1")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_1 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_1": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_2")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_2 input": {
                      "attributes": {
                        "color": "#727272"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_2 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_2": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_3")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_3 input": {
                      "attributes": {
                        "color": "#727272"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_3 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_3": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_4")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_4 input": {
                      "attributes": {
                        "color": "#727272"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_4 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_4": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_5")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_5 input": {
                      "attributes": {
                        "color": "#727272"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_5 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_5": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_6")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_6 input": {
                      "attributes": {
                        "color": "#727272"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_6 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_6": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    } else if(jFirer.is("#s-Input_7")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimChangeStyle",
                  "parameter": [ {
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_7 input": {
                      "attributes": {
                        "color": "#727272"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_7 > .backgroundLayer": {
                      "attributes": {
                        "background-color": "#A4F0AF"
                      }
                    }
                  },{
                    "#s-8e063270-47fd-4daf-9a7e-e5e7241accb4 #s-Input_7": {
                      "attributes-ie": {
                        "-pie-background": "#A4F0AF",
                        "-pie-poll": "false"
                      }
                    }
                  } ],
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });