jQuery("#simulation")
  .on("click", ".s-a0a6e906-8d12-4a0d-b0e5-44a90d9aa375 .click", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-a0a6e906-8d12-4a0d-b0e5-44a90d9aa375")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/27cbc624-4706-4bf8-9e8c-397c92094ea7",
                    "transition": {
                      "type": "flipvertical",
                      "duration": 700
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });