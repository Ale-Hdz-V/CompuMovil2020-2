(function(window, undefined) {
  var dictionary = {
    "5e2b31d2-e855-4a0b-9c24-dd0359e6616c": "Loading_alert",
    "8d9a2f16-4790-456d-bfcf-7837c2d8a49b": "alert_delete",
    "e52ef747-6255-4a2e-a534-7380a64f3583": "Resume",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Loading",
    "27cbc624-4706-4bf8-9e8c-397c92094ea7": "Logout_alert",
    "7285db97-bfbc-4b76-9591-3c4f553056fb": "Signup",
    "a0a6e906-8d12-4a0d-b0e5-44a90d9aa375": "alert",
    "314e974c-34d4-4307-bb33-d7a0f406eea6": "Dashboard",
    "6dee8bc9-e606-4e1e-a04f-6b3aae6af073": "Login",
    "8e063270-47fd-4daf-9a7e-e5e7241accb4": "Edit",
    "a5f3cd5a-6b64-4e39-9068-8cf686146ce4": "Logout",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);